from django.apps import AppConfig


class TotusConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'totus'
